const http = require("http");

const server = http.createServer((req, res) => {
  if (req.url === "/health/ready") {
    if (process.env.READY !== "true") {
      res.writeHead(503, { "Content-Type": "text/plain" });
      return res.end("not ready");
    }
    res.writeHead(200, { "Content-Type": "text/plain" });
    return res.end("ready");
  }

  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(JSON.stringify({
    application: "NPTEL course registration",
    version: process.env.APP_VERSION || "unknown"
  }));
});

server.listen(3000, "0.0.0.0");
